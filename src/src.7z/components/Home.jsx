import React, { useEffect, useState} from "react";
import Axios from "axios";
import AOS from "aos";
import "aos/dist/aos.css";

import Mastercard from "../resources/Mastercard-Logo.png"
import Visa from "../resources/visa.png"

import { Link } from "react-router-dom";
import { mobile } from "./Navigation";

function Home() {
  const [ItemData, setData] = useState([]);

  var colorCount = 0;

  const getData = () => {
    Axios.get("https://api.armilla.lt:8443/api/Popular").then((response) => {
      setData(response.data);
    });
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    getData();
    AOS.init();
    AOS.refresh();
  }, []);

  function getAnim(index){
    if(mobile === false){ // desktop 
      if(index === 0) return "fade-down-right" // first item
      else if (index === 1) return "fade-down"
      else return "fade-down-left"
    } else {
      return "fade-down"
    }
  }

  return (
    <div className="App">
      <div className="intro">
        <h1 data-aos="fade-down">Armilla</h1>
        <h5 data-aos="fade-up">3D spausdintų daiktų parduotuvė ir paslaugų tiekėjas</h5>
      </div>

      <svg
        className="waves"
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        viewBox="0 24 150 28"
        preserveAspectRatio="none"
      >
        <defs>
          <path
            id="gentle-wave"
            d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z"
          />
        </defs>
        <g className="parallax">
          <use
            xlinkHref="#gentle-wave"
            x="48"
            y="0"
            fill="rgba(255,255,255,0.7)"
          />
          <use
            xlinkHref="#gentle-wave"
            x="48"
            y="3"
            fill="rgba(255,255,255,0.5)"
          />
          <use
            xlinkHref="#gentle-wave"
            x="48"
            y="5"
            fill="rgba(255,255,255,0.3)"
          />
          <use xlinkHref="#gentle-wave" x="48" y="7" fill="rgba(255,255,255)" />
        </g>
      </svg>

      <section className="py-0" id="introduction">
        <div className="container" data-aos="fade-up">
          <div className="st-0 flex text-center">
            <h5 className="st-1">ARMILLA.LT</h5>
            <h2 className="st-2">Kas mes?</h2>
            <p>Kokias paslaugas teikiame bei kokiais produktais prekiaujame</p>
          </div>
          <div className="container" id="introContainer">
            <div className="introduction" data-aos="fade-right">
              <div>
                <p>Mūsų parduotuvėje galite rasti įvairių dekoracijų, dovanų idėjų, bei gyvenimą palengvinančių produktų.</p>
                <p>
                  Taip pat 3D Spausdiname ir pjauname lazerinėmis staklėmis pagal užsakymą
                   - Galite užsisakyti
                  daiktus, kurių nėra mūsų parduotuvėje.
                </p>
                <p>Visos mūsų prekės prieš išsiuntimą yra patikriniamos dėl defektų, todėl garantuojame, kad gausite
                  tik aukštos kokybės produktus.
                  Klausomės jūsų kritikos bei rekomendacijų ir visuomet bandome gerinti mūsų produktų kokybę. </p>
                <p className="margin0">Dauguma mūsų produktų yra gaminami 3D Spausdintuvais bei lazerinėmis staklėmis.</p>
              </div>
            </div>
            <div className="blobDiv" data-aos="fade-left">
              <div className="blob"></div>
            </div>
          </div>
        </div>

      </section>

      <section className="py-0" id="features">
        <div className="container" data-aos="fade-up">
          <div className="st-0 flex text-center">
            <h5 className="st-1">SAVYBĖS</h5>
            <h2 className="st-2">Kodėl rinktis mus?</h2>
            <p>Kodėl mes geriausi mūsų srityje</p>
          </div>
        </div>
        <div className="container">
          <div className="flex" id="cardContainer">
            <div className="card" data-aos="zoom-in">
              <div className="cardMargin">
                <div className="cardHead">
                  <div className="BGI flex">
                    <i className="fa-solid fa-hand-holding-dollar"></i>
                  </div>
                  <h5>Investuojame atgal</h5>
                </div>
                <p>
                  Dalis pelno yra investiojama atgal į Armilla,
                  taip geriname produktų kokybę ir svetainės funkcionalumą.
                </p>
              </div>
            </div>
            <div className="card" data-aos="zoom-in">
              <div className="cardMargin">
                <div className="cardHead">
                  <div className="BGI flex">
                    <i className="fa-solid fa-heart"></i>
                  </div>
                  <h5>Klausomės jūsų</h5>
                </div>
                <p>
                  Mes klausomės jūsų pastabų bei rekomendacijų ir remdamiesi
                  jomis nuolat bandome tobulėti.
                </p>
              </div>
            </div>
            <div className="card" data-aos="zoom-in">
              <div className="cardMargin">
                <div className="cardHead">
                  <div className="BGI flex">
                    <i className="fa-solid fa-layer-group"></i>
                  </div>
                  <h5>Inovuojame</h5>
                </div>
                <p>
                Eksperimentuojame su įvairiais produktų gavybos būdais,
                 testuojame įvairiausias liejimo medžiagas.
                </p>
              </div>
            </div>
            <div className="card" data-aos="zoom-in">
              <div className="cardMargin">
                <div className="cardHead">
                  <div className="BGI flex">
                  <i className="fa-solid fa-box-open"></i>
                  </div>
                  <h5>Garantuojame kokybę</h5>
                </div>
                <p>
                  Visi parduodami produktai yra peržiūrimi komandos narių,
                  įsitikinti jų kokybe, teikiame 14 dienų garantiją.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-0" id="PopProducts">
        <div className="container" data-aos="fade-up">
          <div className="st-0 flex text-center">
            <h5 className="st-1">PRODUKTAI</h5>
            <h2 className="st-2">Populiariausi produktai</h2>
            <p>Perkamiausi mūsų parduotuvės produktai</p>
          </div>
        </div>
        <div className="container">
          <div className="itemDivHome">
            {ItemData.map((ItemData, index) => (
              <div className="item-card-wrapper" data-aos={getAnim(index)}>
                <div className="item-card">
                  <div className="box-up">
                    <img className="img" src={ItemData.Materials[ItemData.selectedMaterial].Colors[ItemData.selectedColor].Image} alt="" />
                    <div className="img-info">
                      <div className="info-inner">
                        <span className="p-name">{ItemData.Name}</span>
                      </div>
                      <div className="a-variant">
                        <span className="bold"> {ItemData.Sizes.length} </span>
                        { ItemData.Sizes.length > 1 ? 
                        ( ItemData.Sizes.length > 9 ?
                        (<> Dydžių</>) : (<> Dydžiai</>)) : (<> Dydis</>)
                        }
                      </div>
                      <div className="a-variant a-materials">
                      <span className="bold">{ItemData.Materials.length}</span>
                      { ItemData.Materials.length > 1 ? 
                      ( ItemData.Materials.length > 9 ?
                      (<> Medžiagų</>) : (<> Medžiagos</>)) : (<> Medžiaga</>)
                      }</div>
                      <div className="a-variant a-colors">
                      {ItemData.Materials.map((mat, matIndex) => {
                          if(matIndex === 0){colorCount = 0}
                          colorCount += mat.Colors.length
                        })
                      }
                      <span className="bold">{colorCount}</span>
                        { colorCount > 1 ? 
                        ( colorCount > 9 ?
                        (<> Spalvų</>) : (<> Spalvos</>)) : (<> Spalva</>)
                      }</div>
                    </div>
                  </div>

                  <div className="box-down">
                    <div className="h-bg">
                      <div className="h-bg-inner"></div>
                    </div>

                    <Link className="cart" to={"/products?id=" + ItemData.ID}>
                      <span className="price">{ItemData.Price + ItemData.Materials[ItemData.selectedMaterial].Colors[ItemData.selectedColor].Extra} €</span>
                      <span className="add-to-cart">
                        <span className="txt">Peržiūrėti</span>
                      </span>
                    </Link>
                  </div>
                </div>
              </div>
          ))}
          </div>
        </div>
      </section>
      <section className="flex" id="paymentOptSec">
        <div className="flex" id="paymentOpt">
          <img src={Mastercard} alt="" data-aos="fade-up" data-aos-delay="100"></img>
          <img src={Visa} alt="" data-aos="fade-up" data-aos-delay="200"></img>
        </div>
      </section>
    </div>
  );
}

export default Home;
