import React, { useEffect } from "react";
import Axios from "axios";
import { useState } from "react";

import { Link } from "react-router-dom";

import "./Styles/product-card.css";
import "./Styles/productsMain.css";

function Dekoracijos() {
  const [ItemData, setData] = useState([]);

  var colorCount = 0;

  const getData = (Category, ItemCount) => {
    setData([]); // set data to nothing so loading icon shows

    Axios.post("https://api.armilla.lt:8443/Products", {
      Category: Category,
      ItemCount: ItemCount,
    }).then((response) => {
      const CategoryEl = document.getElementsByClassName("category");
      setData(response.data);
      for (var i = 0; i < CategoryEl.length; i++) {
        // these if statements are kinda cancer but it works
        CategoryEl[i].classList = "category";
        if (Category === "All") {
          CategoryEl[0].classList = "category cSelected";
        } else if (Category === "Dekoracija") {
          CategoryEl[1].classList = "category cSelected";
        } else if (Category === "Naudinga") {
          CategoryEl[2].classList = "category cSelected";
        } else if (Category === "Meme") {
          CategoryEl[3].classList = "category cSelected";
        }
      }
    });
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    getData("All", 69);
  }, []);

  return (
    <div className="ContentItems">
      <div id="productsMain">
        <div className="side-nav-categories">
          <div className="title">
            <strong>Kategorijos</strong>
          </div>
          <ul className="category-tabs">
            <li>
              <a href="javascript:void" className="main-category">
                {" "}
                3D Spausdinimas / medžio pjovimas<i class="fa fa-minus"></i>
              </a>
              <ul className="sub-category-tabs">
                <li>
                  <a href="javascript:void">Dekoracijos</a>
                </li>
                <li>
                  <a href="javascript:void">Naudinga</a>
                </li>
                <li>
                  <a href="javascript:void">Meme</a>
                </li>
              </ul>
            </li>
          </ul>
          <ul className="category-tabs">
            <li>
              <a href="javascript:void" className="main-category">
                Elektronika<i class="fa fa-minus"></i>
              </a>
              <ul className="sub-category-tabs">
                <li>
                  <a href="javascript:void">Amongus</a>
                </li>
              </ul>
            </li>
          </ul>
          <ul className="category-tabs">
            <li>
              <a href="javascript:void" className="main-category">
                Kita<i class="fa fa-minus"></i>
              </a>
              <ul className="sub-category-tabs">
                <li>
                  <a href="javascript:void">Nuke</a>
                </li>
              </ul>
            </li>
          </ul>
        </div>
        {ItemData.length ? (
          <div className="ItemDiv">
            {ItemData.map((ItemData) => (
              <div className="item-card-wrapper">
                <div className="item-card">
                  <div className="box-up">
                    <img
                      className="img"
                      src={
                        ItemData.Materials[ItemData.selectedMaterial].Colors[
                          ItemData.selectedColor
                        ].Image
                      }
                      alt=""
                    />
                    <div className="img-info">
                      <div className="info-inner">
                        <span className="p-name">{ItemData.Name}</span>
                      </div>
                      <div className="a-variant">
                        <span className="bold"> {ItemData.Sizes.length} </span>
                        {ItemData.Sizes.length > 1 ? (
                          ItemData.Sizes.length > 9 ? (
                            <> Dydžių</>
                          ) : (
                            <> Dydžiai</>
                          )
                        ) : (
                          <> Dydis</>
                        )}
                      </div>
                      <div className="a-variant a-materials">
                        <span className="bold">
                          {ItemData.Materials.length}
                        </span>
                        {ItemData.Materials.length > 1 ? (
                          ItemData.Materials.length > 9 ? (
                            <> Medžiagų</>
                          ) : (
                            <> Medžiagos</>
                          )
                        ) : (
                          <> Medžiaga</>
                        )}
                      </div>
                      <div className="a-variant a-colors">
                        {ItemData.Materials.map((mat, matIndex) => {
                          if (matIndex === 0) {
                            colorCount = 0;
                          }
                          colorCount += mat.Colors.length;
                        })}
                        <span className="bold">{colorCount}</span>
                        {colorCount > 1 ? (
                          colorCount > 9 ? (
                            <> Spalvų</>
                          ) : (
                            <> Spalvos</>
                          )
                        ) : (
                          <> Spalva</>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="box-down">
                    <div className="h-bg">
                      <div className="h-bg-inner"></div>
                    </div>

                    <Link className="cart" to={"/products?id=" + ItemData.ID}>
                      <span className="price">
                        {ItemData.Price +
                          ItemData.Materials[ItemData.selectedMaterial].Colors[
                            ItemData.selectedColor
                          ].Extra}{" "}
                        €
                      </span>
                      <span className="add-to-cart">
                        <span className="txt">Peržiūrėti</span>
                      </span>
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="ItemDiv flex">
            <div className="lds-ripple">
              <div></div>
              <div></div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default Dekoracijos;

/*      <div className="categories">
        <span className="category" onClick={() => getData("All", 69)}>Visi Produktai</span>
        <span className="category" onClick={() => getData("Dekoracija", 420)}>Dekoracijos</span>
        <span className="category" onClick={() => getData("Naudinga", 6969)}>Naudinga</span>
        <span className="category" onClick={() => getData("Meme", 69420)}>Meme</span>
      </div> */
