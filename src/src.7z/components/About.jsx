import React, { useEffect } from "react";
import "aos/dist/aos.css";
import "./Styles/About.css";
import AOS from "aos";

function About() {
  useEffect(() => {
    window.scrollTo(0, 0);
    AOS.init();
    AOS.refresh();
  }, []);

  return (
    <div className="AppAbout">
      <div id="About-page-header">
        <h4>Apie Mus</h4>
      </div>

      <section id="about-content-section">
        <div className="about-content-div flex ">
          <div className="about-text-div flex" data-aos="fade-right">
            <div className="about-text-title">
              <h2>Kas Mes</h2>
            </div>
            <p>
              Armilla.lt kuria ir prekiauja aukštos kokybės 3D spausdintus ir
              lazeriu pjautus produktus - Dekoracijas, dovanas ir kasdieninį
              gyvenimą palengvinančius produktus.
            </p>
            <p>
              Armilla.lt taip pat priima privačius užsakymus - Galite užsisakyti
              jums norimą 3D spausdinti ar pjauti lazerio staklėmis užsakymą
              kompetitingomis kainomis.
            </p>
          </div>
          <div className="about-img-div" data-aos="fade-left">
            <img
              src="https://venngage-wordpress.s3.amazonaws.com/uploads/2018/01/Stock-Photos-Social-Media-Graphic-Design-Example-2.jpg"
              alt=""
            ></img>
          </div>
        </div>
        <div className="about-content-div img-left flex">
          <div className="about-text-div flex" data-aos="fade-left">
            <div className="about-text-title">
              <h2>Komanda</h2>
            </div>
            <p>
              Armilla.lt komandą sudaro nedidelė grupė žmonų, tarp kurių yra
              modeliuotojas, soc. tinklų vedėjas, programuotojas.
            </p>
            <p>
              Visi komandos nariai prisideda prie produktų kokybės ir rūpinasi,
              kad gautumėte aukštos kokybės produktus.
            </p>
            <p>
              Armilla.lt Komanda nuolat renkasi į komandos susirinkimus,
              aptariame, kaip galėtume tobulinti mūsų parduotuvės produktu
              kokybę, internetines sistemas ir bandome vykdyti įvairias idėjas.
            </p>
          </div>
          <div className="about-img-div" data-aos="fade-right">
            <img
              src="https://img.freepik.com/free-photo/graphic-designer-making-logo-notebook_23-2149142115.jpg?w=2000"
              alt=""
            ></img>
          </div>
        </div>
        <div className="about-content-div flex ">
          <div className="about-text-div flex" data-aos="fade-right">
            <div className="about-text-title">
              <h2>Istorija</h2>
            </div>
            <p>
              Parduotuvės, kurioje žmonės galėtu nusipirkti įvairų 3D spausdintų
              dekoracijų idėja startavo KTU Inžinerijos Licėjaus klasėje, kai
              dabartiniai komandos nariai, mes, supratome, kad turime pakankamai
              patirties išbandyti ką nors didesnio - sukurti elektroninę
              parduotuvę, todėl netrukus mes pradėjome galvoti apie produktus,
              kuriuos galėtume pardavinėti. Pirma idėja buvo papuošalai, bet
              netrukus mes persisvėrėme į 3D spausdintus ir lazeriu pjautus
              produktus, kadangi šios gamybos technikos mums buvo lengvai
              prieinamos ir turime komandos narių, kurie yra susipažinę su šiais
              gamybos būdais, bei turėjome komandos narį kuris turi daug
              patirties modeliuojant įvairius dalykus, tarp jų ir pastatą, kuris laimėjo
              KTU DEC projektą. Taip
              gimė Armilla.lt.
            </p>
          </div>
          <div className="about-img-div" data-aos="fade-left">
            <img
              src="https://venngage-wordpress.s3.amazonaws.com/uploads/2018/01/Stock-Photos-Social-Media-Graphic-Design-Example-2.jpg"
              alt=""
            ></img>
          </div>
        </div>
        <div className="about-content-div img-left flex">
          <div className="about-text-div flex" data-aos="fade-left">
            <div className="about-text-title">
              <h2>Kokybės Kontrolė</h2>
            </div>
            <p>
              Visos mūsų prekės prieš išsiuntimą yra patikriniamos dėl defektų,
              todėl garantuojame, kad gausite tik aukštos kokybės produktus.
            </p>
            <p>
              Klausomės jūsų kritikos bei rekomendacijų ir visuomet bandome
              gerinti mūsų produktų kokybę. Klientams gavus užsakytą produktą
              prašome užpildyti anketą, papasakoti kaip galėtume tobulėti, kas
              patiko ir kas, jei, nuvylė.
            </p>
            <p>
              Gavus žemos kokybės ar defektuotą produktą, teikiame 7 dienų nuo
              produkto įsigijimo pinigų grąžinimo garantiją.
            </p>
          </div>
          <div className="about-img-div" data-aos="fade-right">
            <img
              src="https://img.freepik.com/free-photo/graphic-designer-making-logo-notebook_23-2149142115.jpg?w=2000"
              alt=""
            ></img>
          </div>
        </div>
      </section>
    </div>
  );
}

/*

      <div className="Container">
        <div className="about flex">
          <h1 data-aos="fade-down" data-aos-delay={getDelay(0, 0)} data-aos-duration="500">Armilla</h1>
          <p data-aos="fade-up" data-aos-delay={getDelay(1, 100)} >Elektroninė parduotuvė, teikianti jums galimybę rinktis iš daugybės aukščiausios kokybės produktų.
          </p>
          <h5 data-aos="fade-up" data-aos-delay={getDelay(1, 200)}>Ką daro Armilla?</h5>
          <p data-aos="fade-up" data-aos-delay={getDelay(1, 250)}>Armilla gamina aukščiausios kokybės įvairių medžiagų ir paskirčių produktus, tokius kaip dekoracijas,
          naudingus daiktus, šio metu užsiimame tik 3D spausdintais produktais, tačiau artimoje ateityje tikimės svetainę papildyti ir "Acrylic" medžiagos produktų gamyba, 
          su kuria šiuo metu eksperimentuojame. Tolimesnėje ateityje planuojame eksperimentuoti su metalo liejimu.
           </p>
          <h5 data-aos="fade-up" data-aos-delay={getDelay(1, 300)}>Kodėl Armilla yra geriausia šioje srityje?</h5>
            <p data-aos="fade-up" data-aos-delay={getDelay(1, 350)}>Mes klausomės jūsų pastabų ir rekomendacijų, todėl mūsų produktais tikrai nenusivilsite.
            Turime komandą aktyvių ir motyvuotų žmonių, kurie nuolat galvoja kaip galėtume gerinti gamybos procesą, produktų kokybę. Inovuojame eksperimentuodami
            su skurtingomis medžiagomis, gamybos procesais, turime dedikuotą 3D modeliuotoją, kuris žmonių idėjas paverčia realybe.</p>
          <h5 data-aos="fade-up" data-aos-delay={getDelay(1, 400)}>Kas numatyta Armilla ateityje</h5>
            <p data-aos="fade-up" data-aos-delay={getDelay(1, 450)}>Artimoje ateityje tikimės prie mūsų katalogo pridėti ir "Acrylic" medžiagos produktus, su šia medžiaga
            šuo metu eksperimentuojame, turėjome idėjų su įvairių formų išlietu maistu - guminukais, žele. Tolimesnėje ateityje planuojame eksperimentuoti su metalo perdirbimu ir liejimu, ir, jei pasiseks, prijungti metalo gaminius prie 
            katalogo.</p>
          <h5 data-aos="fade-up" data-aos-delay={getDelay(1, 500)}>Kodėl turėtumėte pasitikėti Armilla</h5>
            <p data-aos="fade-up" data-aos-delay={getDelay(1, 550)}>Mes klausomės jūsų pastabų ir rekomendacijų, todėl mūsų produktais tikrai nenusivilsite. Jei nutinka taip, kad 
            produktas pas jus nusigavo pažeistas, ar juo tikrai esate nusivylę, mes teikiame 7 dienų garantiją, per kurią pinigus už produktą galime gražinti.</p>
          <div id="policies">
          <Link rel="noreferrer" to="/documents" >Paslaugų teikimo sąlygos</Link>
          | <Link rel="noreferrer" to="/documents?id=privacy-policy"  target="_blank">Privatumo politika</Link>
          | <Link rel="noreferrer" to="/documents?id=refund-policy" target="_blank">Grąžinimo politika</Link>
          </div>
        </div>
      </div>

*/

export default About;
